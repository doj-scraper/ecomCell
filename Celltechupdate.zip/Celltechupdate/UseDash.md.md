user Dashboard 

The User Dashboard is the central hub for your customers, especially the B2B/wholesale clients who will be ordering repair parts frequently.
Since we already secured the /dashboard route using NextAuth middleware in Phase 2B, we can safely build this as a suite of Server Components. This means we can fetch their secure order history directly on the server before the page even renders, ensuring zero loading spinners for the main layout.
Here is the architecture for the protected User Dashboard.
1. The Dashboard Layout (app/dashboard/layout.tsx)
In the Next.js App Router, layouts persist across route changes. This is the perfect place to put the dashboard sidebar, ensuring it stays locked in place while the user clicks between "Overview", "Orders", and "Settings".
import { ReactNode } from 'react';
import Link from 'next/link';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { User, Package, Settings, LogOut } from 'lucide-react';

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  // 1. Double-check Auth (Middleware handles routing, but we need the session data)
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect('/login');
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] bg-background">
      {/* 2. Industrial Sidebar */}
      <aside className="w-64 border-r border-industrial-800 flex flex-col justify-between">
        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-1">
              Logged In As
            </h2>
            <p className="font-bold truncate">{session.user.email}</p>
            {/* Display Wholesale/Retail Badge */}
            <span className="inline-block mt-2 px-2 py-1 bg-industrial-800 text-[10px] font-mono uppercase border border-industrial-700">
              {session.user.role} ACCOUNT
            </span>
          </div>

          <nav className="space-y-2 font-mono text-sm uppercase tracking-wide">
            <Link href="/dashboard" className="flex items-center gap-3 p-3 hover:bg-industrial-900 border border-transparent hover:border-industrial-700 transition-all">
              <User className="w-4 h-4 opacity-70" />
              Overview
            </Link>
            <Link href="/dashboard/orders" className="flex items-center gap-3 p-3 bg-industrial-900 border border-industrial-700 text-primary">
              <Package className="w-4 h-4" />
              Order History
            </Link>
            <Link href="/dashboard/settings" className="flex items-center gap-3 p-3 hover:bg-industrial-900 border border-transparent hover:border-industrial-700 transition-all">
              <Settings className="w-4 h-4 opacity-70" />
              Settings
            </Link>
          </nav>
        </div>

        {/* Logout (Handled by NextAuth signOut client-side, but this is the visual wrapper) */}
        <div className="p-6 border-t border-industrial-800">
          <button className="flex items-center gap-3 text-sm font-mono uppercase text-destructive hover:opacity-80 transition-opacity">
            <LogOut className="w-4 h-4" />
            Disconnect
          </button>
        </div>
      </aside>

      {/* 3. The Active Page Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}

2. Fetching Protected Data (app/dashboard/orders/page.tsx)
This is the order history page. Notice how we extract the accessToken from the NextAuth session and use it to securely query your Express backend.
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';

// Define the shape of the data returning from Express
interface Order {
  id: string;
  createdAt: string;
  totalAmount: number;
  status: 'PENDING' | 'PAID' | 'SHIPPED' | 'CANCELLED';
  _count: { items: number };
}

export default async function OrdersPage() {
  const session = await getServerSession(authOptions);

  // 1. Fetch from Express using the Bearer Token
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/orders/me`, {
    headers: {
      Authorization: `Bearer ${session?.accessToken}`,
    },
    // Don't cache order history, always show the freshest data
    cache: 'no-store', 
  });

  const orders: Order[] = res.ok ? await res.json() : [];

  return (
    <section className="max-w-5xl">
      <header className="mb-8 border-b border-industrial-800 pb-4">
        <h1 className="text-3xl font-bold uppercase tracking-tight">Order History</h1>
        <p className="text-muted-foreground font-mono text-sm mt-2">
          View and track your repair part shipments.
        </p>
      </header>

      {orders.length === 0 ? (
        <div className="p-12 border border-industrial-800 border-dashed flex flex-col items-center justify-center text-center">
          <p className="font-mono text-muted-foreground uppercase tracking-widest mb-4">No records found</p>
          <Link href="/catalog" className="px-6 py-3 bg-primary text-primary-foreground font-bold uppercase text-xs">
            Browse Catalog
          </Link>
        </div>
      ) : (
        <div className="border border-industrial-800 bg-industrial-950/50">
          {/* 2. Data-Dense Table for Industrial Feel */}
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-industrial-800 font-mono text-xs uppercase tracking-widest text-muted-foreground bg-industrial-900">
                <th className="p-4 font-normal">Order ID</th>
                <th className="p-4 font-normal">Date</th>
                <th className="p-4 font-normal">Status</th>
                <th className="p-4 font-normal text-right">Items</th>
                <th className="p-4 font-normal text-right">Total</th>
                <th className="p-4 font-normal"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-industrial-800">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-industrial-900/50 transition-colors group">
                  <td className="p-4 font-mono text-xs">
                    {order.id.slice(-8).toUpperCase()}
                  </td>
                  <td className="p-4">
                    {new Date(order.createdAt).toLocaleDateString('en-US', { 
                      year: 'numeric', month: 'short', day: 'numeric' 
                    })}
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-[10px] font-mono uppercase tracking-wider border ${
                      order.status === 'PAID' ? 'border-green-500/50 text-green-400 bg-green-500/10' :
                      order.status === 'SHIPPED' ? 'border-blue-500/50 text-blue-400 bg-blue-500/10' :
                      'border-industrial-700 text-muted-foreground'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="p-4 text-right font-mono">{order._count.items}</td>
                  <td className="p-4 text-right font-mono text-primary">
                    ${(order.totalAmount / 100).toFixed(2)}
                  </td>
                  <td className="p-4 text-right">
                    <Link 
                      href={`/dashboard/orders/${order.id}`} 
                      className="inline-flex items-center gap-1 text-xs uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors"
                    >
                      View <ArrowUpRight className="w-3 h-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

3. The Backend Express Route (controllers/orderController.ts)
To make the Next.js page above work, your Express backend needs an endpoint that validates the user's JWT and queries the Prisma database.
import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const getMyOrders = async (req: Request, res: Response) => {
  try {
    // `req.user.id` is populated by your Express Auth Middleware 
    // that verifies the JWT sent in the Authorization header.
    const userId = req.user?.id; 

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const orders = await prisma.order.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: {
        // Just pull the count of items for the overview table to save bandwidth
        _count: { select: { items: true } } 
      }
    });

    res.status(200).json(orders);
  } catch (error) {
    console.error('[Order Controller] Failed to fetch orders:', error);
    res.status(500).json({ error: 'Failed to retrieve order history' });
  }
};

This completes the entire user flow from landing on the catalog to viewing their receipts in the dashboard.
With the Fitment Checker, the Auth integration, the Stripe webhooks, and the User Dashboard all mapped out, you have a comprehensive guide for all of Phase 2.
Would you like me to compile all the backend logic (Controllers, Middlewares, Webhooks) and the updated schema.prisma into a final checklist so you can track your progress as you build the Express side of this architecture?
