 (app/catalog/page.tsx)
This page will use a Two-Panel Layout:
 * Sidebar (Filter Tree): A hierarchical navigation of Brand → Series → Model.
 * Main Content (Product Grid): A dynamic grid that filters based on the Sidebar selection.
1. Data Structure & State
To keep the UI snappy, we should fetch the Device Tree (the nested brands and models) as a static JSON object or a cached RSC (React Server Component) call.
 * activeFilters: An object in the URL search params (e.g., ?brand=apple&model=iphone-13). Using URL params instead of local state allows users to bookmark their specific device's parts page.
 * DeviceNode:
   interface DeviceNode {
  id: string;
  label: string;
  children?: DeviceNode[]; // For nesting Series under Brands
}

2. Implementation: The Page Component
import { Suspense } from 'react';
import DeviceSidebar from '@/components/catalog/DeviceSidebar';
import ProductGrid from '@/components/catalog/ProductGrid';
import { getDeviceTree, getProductsByDevice } from '@/lib/api';

interface CatalogPageProps {
  searchParams: Promise<{ brand?: string; series?: string; model?: string }>;
}

export default async function CatalogPage({ searchParams }: CatalogPageProps) {
  const filters = await searchParams;
  
  // 1. Fetch the navigation tree (Brands/Series)
  const deviceTree = await getDeviceTree();

  return (
    <main className="flex min-h-screen pt-16">
      {/* LEFT PANEL: The Drill-Down Sidebar */}
      <aside className="w-64 border-r border-industrial-700 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
        <div className="p-4 bg-background">
          <h2 className="text-xs font-mono uppercase tracking-widest mb-6 opacity-50">
            Device Explorer
          </h2>
          <DeviceSidebar tree={deviceTree} activeFilters={filters} />
        </div>
      </aside>

      {/* RIGHT PANEL: The Content Area */}
      <section className="flex-1 p-8">
        <header className="mb-8">
          <h1 className="text-3xl font-bold uppercase">
            {filters.model || filters.brand || "All Parts"}
          </h1>
          <p className="text-muted-foreground font-mono text-sm mt-2">
            Showing results for: {filters.brand || 'Global'} / {filters.series || 'All'}
          </p>
        </header>

        {/* 2. Async Product Grid with Suspense for Loading States */}
        <Suspense fallback={<ProductGridSkeleton />}>
          <ProductGridContainer filters={filters} />
        </Suspense>
      </section>
    </main>
  );
}

// Internal Server Component to handle filtered product fetching
async function ProductGridContainer({ filters }: { filters: any }) {
  const products = await getProductsByDevice(filters);
  return <ProductGrid products={products} />;
}

3. Key Functional Behaviors
| Feature | Requirement |
|---|---|
| URL Sync | Clicking a Brand in the sidebar updates the URL ?brand=x. This triggers a server-side re-render of the ProductGridContainer. |
| Visual Hierarchy | When "Apple" is selected, the sidebar expands to show "iPhone", "iPad", "MacBook". This state is derived from the activeFilters prop. |
| "My Device" Shortcut | If useDeviceStore (Zustand) has a savedDevice, the Sidebar should have a top-level "⚡ My Device" button that instantly applies the correct filters. |
| Infinite Scroll/Pagination | The ProductGrid should support fetching more parts as the user scrolls, ideally using a useActionState or a simple fetch trigger. |
4. Discussion: The Product Card
Since you're moving from a generic grid to a proper catalog, what info is vital on the Card itself?
 * Stock Status: (In Stock / Low Stock / Out of Stock)
 * Wholesale Tiers: Do you want to show the "Starting at $XX.XX" price for bulk buyers immediately?
 * Quick Add: Should "Add to Cart" be available directly on the card, or must they visit the PDP to verify fitment first? (I recommend a "Check Fitment" button that opens the PDP or a modal if no device is saved).
Would you like me to move to Step 3: The Cart Drawer (components/cart-drawer.tsx) and wire it to your existing useCartStore?


Since the logic for useCartStore is already scaffolded in your codebase, the goal for Step 3 is to build a high-performance, accessible Cart Drawer using the shadcn Sheet component.
This component serves as the bridge between the Device Explorer and the Stripe Checkout.
Functional Specification: CartDrawer.tsx
The drawer must handle three primary states: Empty, Active, and Syncing.
1. Store Integration (Zustand)
The component will subscribe to the existing useCartStore. We need to ensure the following selectors are utilized to prevent unnecessary re-renders of the entire drawer:
 * items: The array of products currently in the cart.
 * totalAmount: Computed sum of all items (Product Price × Quantity).
 * updateQuantity: Function to increment/decrement items.
 * removeItem: Function to purge a SKU from the cart.
2. Component Implementation
'use client';

import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetFooter 
} from '@/components/ui/sheet'; // Standard shadcn/ui path
import { useCartStore } from '@/store/useCartStore';
import { useAppStore } from '@/store/useAppStore'; // To control open/close state
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function CartDrawer() {
  const router = useRouter();
  
  // 1. Selectors from your scaffolded stores
  const { items, updateQuantity, removeItem, totalAmount } = useCartStore();
  const { isCartOpen, toggleCart } = useAppStore();

  const handleCheckout = () => {
    toggleCart(); // Close drawer
    router.push('/checkout');
  };

  return (
    <Sheet open={isCartOpen} onOpenChange={toggleCart}>
      <SheetContent className="w-full sm:max-w-md flex flex-col bg-background border-l border-industrial-800">
        <SheetHeader className="border-b border-industrial-800 pb-4">
          <SheetTitle className="flex items-center gap-2 uppercase tracking-tight">
            <ShoppingBag className="w-5 h-5" />
            Repair Cart ({items.length})
          </SheetTitle>
        </SheetHeader>

        {/* 2. Scrollable Item List */}
        <div className="flex-1 overflow-y-auto py-6">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center opacity-40">
              <p className="font-mono text-sm">CART_IS_EMPTY</p>
            </div>
          ) : (
            <div className="space-y-6">
              {items.map((item) => (
                <div key={item.skuId} className="flex gap-4 group">
                  <div className="w-20 h-20 bg-industrial-900 border border-industrial-800 shrink-0">
                    {/* Placeholder for Product Image */}
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="text-sm font-bold leading-tight">{item.name}</h4>
                      <p className="text-xs font-mono opacity-50">{item.skuId}</p>
                    </div>
                    
                    {/* 3. Quantity Controls */}
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border border-industrial-700">
                        <button 
                          onClick={() => updateQuantity(item.skuId, item.quantity - 1)}
                          className="p-1 hover:bg-industrial-800"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-3 text-xs font-mono">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.skuId, item.quantity + 1)}
                          className="p-1 hover:bg-industrial-800"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <button 
                        onClick={() => removeItem(item.skuId)}
                        className="text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 4. Sticky Footer with Totals */}
        {items.length > 0 && (
          <SheetFooter className="border-t border-industrial-800 pt-6 flex-col gap-4">
            <div className="flex justify-between items-end">
              <span className="text-xs font-mono uppercase opacity-50">Subtotal</span>
              <span className="text-xl font-bold font-mono">${totalAmount.toFixed(2)}</span>
            </div>
            <button 
              onClick={handleCheckout}
              className="w-full py-4 bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:brightness-110 transition-all"
            >
              Proceed to Checkout
            </button>
            <p className="text-[10px] text-center opacity-40 font-mono">
              TAX AND SHIPPING CALCULATED AT CHECKOUT
            </p>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  );
}

3. Critical Functional Behaviors
| Feature | Requirement |
|---|---|
| Optimistic Updates | Quantity changes must reflect in the UI immediately. If Step 6 (Backend Persistence) is active, the sync should happen in a useEffect or via a debounced background fetch. |
| Inventory Validation | (Future) If an item's quantity exceeds current stock from the Redis cache, the "Plus" button should disable and show a "Max Stock" tooltip. |
| The Navigation Trigger | Your navigation.tsx needs a button that calls toggleCart(). It should feature a badge showing items.length. |
| Cart Persistence | Since this is Next.js, ensure your useCartStore uses the persist middleware (localstorage) so the cart isn't wiped if the user refreshes. |
4. Next: Transition to Phase 2B (Auth)
With the Product Detail Page, Catalog, and Cart Drawer built, the frontend user flow is nearly complete. The next blocker is Checkout, which requires a logged-in user to handle shipping and Stripe customer IDs.
Would you like me to move to Step 4: NextAuth Configuration? I can draft the [...nextauth]/route.ts handler and the middleware to protect your /dashboard and /checkout routes.

fitment dats 

To keep this aligned with your Next.js 15 App Router architecture, we will build this as a Server Component. This ensures the initial fitment data is fetched on the server, improving SEO and reducing the client-side bundle size.
app/product/[skuId]/page.tsx
import { notFound } from 'next/navigation';
import FitmentChecker from '@/components/FitmentChecker';
// Assuming your lib/api.ts contains these fetchers
import { getProductBySku, getProductCompatibilities } from '@/lib/api'; 

interface ProductPageProps {
  params: Promise<{ skuId: string }>;
}

/**
 * Server Component: Product Detail Page (PDP)
 * Fetches product data and compatibility array in parallel.
 */
export default async function ProductPage({ params }: ProductPageProps) {
  const { skuId } = await params;

  // 1. Parallel Data Fetching
  const [product, compatibilities] = await Promise.all([
    getProductBySku(skuId),
    getProductCompatibilities(skuId),
  ]);

  // 2. Guard Clause
  if (!product) {
    notFound();
  }

  return (
    <main className="product-container">
      {/* Visual / Gallery Section (Left) */}
      <section className="product-visuals">
        {/* Component for your Dark Lab / Industrial Gallery */}
        <div className="image-wrapper">
          {/* product.images.map(...) */}
        </div>
      </section>

      {/* Info & Action Section (Right) */}
      <section className="product-details">
        <header className="product-header">
          <h1 className="text-2xl font-bold uppercase tracking-tight">
            {product.name}
          </h1>
          <p className="text-sm text-muted-foreground">SKU: {skuId}</p>
        </header>

        <div className="pricing-tier-block">
          <span className="price-tag">${product.basePrice}</span>
          {/* Map your pricing tiers here if available */}
        </div>

        {/* 3. Functional Fitment Integration */}
        <div className="fitment-section border-t border-b py-6 my-6">
          <h3 className="text-xs font-mono mb-4 uppercase opacity-50">
            Hardware Compatibility Check
          </h3>
          <FitmentChecker 
            productSku={skuId} 
            compatibilities={compatibilities} 
          />
        </div>

        <div className="purchase-actions">
          {/* This button would be wired to your Zustand cartStore */}
          <button className="add-to-cart-btn w-full py-4 bg-primary text-white">
            Add to Repair Cart
          </button>
        </div>

        <article className="specs-specs mt-8">
          <h4 className="font-bold mb-2">Technical Specifications</h4>
          <dl className="grid grid-cols-2 gap-2 text-sm">
            {Object.entries(product.specs).map(([key, value]) => (
              <React.Fragment key={key}>
                <dt className="opacity-60">{key}:</dt>
                <dd className="font-medium text-right">{value as string}</dd>
              </React.Fragment>
            ))}
          </dl>
        </article>
      </section>
    </main>
  );
}

Key Architectural Decisions:
 * params as a Promise: In Next.js 15, params is an asynchronous object. We await it at the top of the function to maintain compatibility with the latest App Router standards.
 * Parallel Fetching: Using Promise.all ensures that the product details and the (potentially large) compatibility list are fetched simultaneously, preventing a sequential "waterfall" delay.
 * Hybrid Strategy: Data fetching happens on the Server, while the interactivity of the search and the global "My Garage" persistence happens on the Client inside the FitmentChecker.
 * SEO: Since the static product info is rendered on the server, search engines can index the SKU, name, and technical specs immediately.
Next Step for Design
Now that the data flow from Server to Client is established, we have the logic for Phase 2A (Step 1) complete.
Would you like me to move to Step 2: The "Device Explorer" Catalog Page (app/catalog/page.tsx) with the two-panel brand/model filter tree?


fitment check 


This implementation follows your functional spec strictly: a Client Component that handles the debounced search logic, interfaces with the useDeviceStore for persistence, and categorizes matches into EXACT, PARTIAL, or NO_MATCH.
FitmentChecker.tsx Implementation
'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useDeviceStore } from '@/store/useDeviceStore';
import { Device, FitmentStatus, calculateFitment } from '@/types/fitment';

interface FitmentCheckerProps {
  productSku: string;
  compatibilities: Device[];
  onMatch?: (device: Device) => void;
}

export default function FitmentChecker({ 
  productSku, 
  compatibilities, 
  onMatch 
}: FitmentCheckerProps) {
  // 1. State Management
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const { savedDevice, setSavedDevice, clearSavedDevice } = useDeviceStore();

  // 2. Debounce Logic (150ms as per spec)
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(query);
    }, 150);
    return () => clearTimeout(handler);
  }, [query]);

  // 3. Match Calculation
  const fitment: FitmentStatus = useMemo(() => {
    // If we have a saved device and no active search query, 
    // check if the saved device is in this product's compatibility list
    if (!debouncedQuery && savedDevice) {
      const isCompatible = compatibilities.some(d => d.id === savedDevice.id);
      return {
        status: isCompatible ? 'EXACT' : 'NO_MATCH',
        matchedDevice: isCompatible ? savedDevice : undefined,
        suggestions: []
      };
    }
    
    return calculateFitment(debouncedQuery, compatibilities);
  }, [debouncedQuery, compatibilities, savedDevice]);

  // 4. Persistence Action
  const handleSaveDevice = (device: Device) => {
    setSavedDevice(device);
    if (onMatch) onMatch(device);
    setQuery(''); // Clear search on success
  };

  return (
    <section className="fitment-container">
      {/* Search Input Layer */}
      <div className="search-layer">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter Model Number (e.g. A2633) or Device Name..."
          className="fitment-input"
        />
        {savedDevice && !query && (
          <button onClick={clearSavedDevice} className="clear-btn">
            Clear Saved Device
          </button>
        )}
      </div>

      {/* Results Logic Layer */}
      <div className="results-layer">
        {fitment.status === 'EXACT' && fitment.matchedDevice && (
          <div className="status-exact">
            <span>Confirmed Fit: {fitment.matchedDevice.modelName}</span>
            {!savedDevice && (
              <button onClick={() => handleSaveDevice(fitment.matchedDevice!)}>
                Save to My Devices
              </button>
            )}
          </div>
        )}

        {fitment.status === 'PARTIAL' && (
          <ul className="suggestions-list">
            {fitment.suggestions.map((device) => (
              <li key={device.id} onClick={() => handleSaveDevice(device)}>
                {device.modelName} ({device.modelNumbers.join(', ')})
              </li>
            ))}
          </ul>
        )}

        {fitment.status === 'NO_MATCH' && debouncedQuery.length > 2 && (
          <div className="status-error">
            No compatible hardware found for "{debouncedQuery}".
          </div>
        )}
      </div>
    </section>
  );
}

Functional Highlights:
 * Logic Isolation: The matching logic is wrapped in useMemo to prevent unnecessary re-calculations during re-renders, specifically listening to the debouncedQuery.
 * Automatic Check: If a user already has a savedDevice in their Zustand store, the component automatically validates it against the compatibilities array on mount.
 * Tokenization Support: It handles the transition from searching (Partial) to selecting (Exact) to persisting (Store).
 * Normalization Compatibility: By utilizing the calculateFitment utility we defined earlier, it ignores spaces and hyphens in model numbers.
Final Polish for Phase 2A
Now that the core logic and state are handled, we can integrate this into the Product Detail Page (app/product/[skuId]/page.tsx).
Would you like me to draft the Server Component for the Product Detail Page that fetches the data and passes it into this Fitment Checker?
