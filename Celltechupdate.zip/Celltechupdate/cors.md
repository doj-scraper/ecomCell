Configuring CORS (Cross-Origin Resource Sharing) correctly is the most common stumbling block in a decoupled Next.js + Express architecture. If it’s too loose, your backend is vulnerable; if it’s too strict, your frontend won't be able to fetch data or log users in.
Because your frontend will make two different types of requests (Browser-to-Express and Server-to-Express), your CORS setup needs to be 


Here is the exact production-ready structure for your Express server.ts or app.ts file.

1. The Express CORS Configuration
First, make sure you have the types installed: npm install cors and npm install -D @types/cors.
import express from 'express';
import cors from 'cors';
import routes from './routes'; // Assuming your routes are bundled here

const app = express();

// 1. Define allowed origins (Local dev + Production frontend)

// We filter out undefined values in case FRONTEND_URL isn't set locally
const allowedOrigins = [
  'http://localhost:3000',
  process.env.FRONTEND_URL, // e.g., https://irepair-shop.com
].filter(Boolean) as string[];


// 2. Apply CORS before ANY route definitions
app.use(
  cors({
    origin: function (origin, callback) {
      // Allow requests with no origin. 
      // WHY? Next.js Server Components and Server Actions (like your checkout action) 
      // make server-to-server HTTP requests. These often lack an Origin header.
      if (!origin) return callback(null, true);

      // Check if the origin matches our allowed list.
      // PRO TIP: If you use Vercel Preview Deployments for the frontend, 
      // you can dynamically allow them by checking if the origin ends with '.vercel.app'
      if (
        allowedOrigins.includes(origin) || 
        origin.endsWith('-yourteamname.vercel.app') 
      ) {
        callback(null, true);
      } else {
        callback(new Error('Blocked by strict CORS policy'));
      }
    },
    
    // 3. Allow cookies and Authorization headers to pass through
    credentials: true, 
    
    // 4. Restrict allowed methods
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    
    // 5. Explicitly whitelist the headers your app uses
    allowedHeaders: [
      'Content-Type',
      'Authorization',     // Required for your NextAuth JWT Bearer token
      'stripe-signature',  // CRITICAL: Required for your Stripe Webhook listener
    ],
  })
);

// --- IMPORTANT MIDDLEWARE ORDER ---

// 1. Raw body parser strictly for Stripe Webhooks (MUST be before express.json)
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json' }));

// 2. Standard JSON parser for all other routes
app.use(express.json());

// 3. Mount your routes
app.use('/api', routes);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`iRepair Backend running on port ${PORT}`));

2. Why This Specific Configuration Matters
 * The !origin Check: This is the secret sauce for Next.js App Router. When your app/product/[skuId]/page.tsx Server Component fetches the Fitment array, that request originates from the Vercel server, not a browser. Server-to-server requests often bypass CORS or drop the Origin header. Allowing !origin ensures your Server Components don't get blocked.
 * The credentials: true Flag: Without this, browsers will strip the Authorization: Bearer <token> header out of any fetch requests made from your Client Components (like the User Dashboard), causing your Express auth middleware to constantly return 401 Unauthorized.
 * The Middleware Order (The Stripe Trap): Notice how express.raw() for the Stripe webhook is mounted before express.json(). If express.json() runs first, it converts the incoming Stripe payload into a JavaScript object, mutating the raw bytes. When Stripe tries to verify the cryptographic signature against the mutated bytes, it will fail every time.
Ready to build?
With the database schema, Express controllers, Redis caching, Next.js frontend components, Server Actions, environment variables, and now the exact CORS configuration fully documented, you have the complete architectural blueprint for CRODA Consulting to build this out.
Here is the complete environment variable mapping. Since you are running a decoupled architecture, managing CORS (Cross-Origin Resource Sharing) and keeping your secrets isolated between these two environments is critical.

1. Frontend: Next.js 15 (.env.local)
The frontend environment focuses on NextAuth configuration and public-facing API pointers. Variables prefixed with NEXT_PUBLIC_ are exposed to the browser; everything else is securely locked to the server components.
# --- NEXT.JS CORE ---
# The URL of your Next.js application (required for NextAuth callbacks)
# Local: http://localhost:3000 | Prod: https://irepair-shop.com
NEXTAUTH_URL="http://localhost:3000"

# A random 32+ character string used to encrypt the NextAuth JWT session
# Generate via terminal: openssl rand -base64 32
NEXTAUTH_SECRET="your_generated_secret_here"

# --- BACKEND CONNECTION ---
# The URL of your Express API. 
# Local: http://localhost:8080 | Prod: https://celltech-backend.vercel.app
NEXT_PUBLIC_API_URL="http://localhost:8080"

# --- STRIPE (Optional for Phase 2D) ---
# Only needed on the frontend if you decide to use embedded Stripe Elements 
# instead of the Stripe Checkout redirect page.
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_test_..."

2. Backend: Express / Prisma (.env)
The backend is the vault. It holds all the keys to the database, Redis, and Stripe. None of these variables should ever be exposed to the browser.

# --- DATABASE (Prisma) ---
# The connection pooler URL for Vercel serverless (e.g., Supabase Transaction pooler)
DATABASE_URL="postgres://user:password@pooler-host:6543/dbname?pgbouncer=true"

# The direct connection URL used strictly for running `npx prisma db push` or migrations
DIRECT_URL="postgres://user:password@direct-host:5432/dbname"

# --- CACHING ---
# Connection string for your Redis instance (e.g., Upstash)
REDIS_URL="rediss://default:password@your-upstash-endpoint.upstash.io:30000"

# --- AUTHENTICATION ---
# The secret Express uses to sign the JWTs it hands to Next.js upon login
# Generate via terminal: openssl rand -base64 32
JWT_SECRET="different_generated_secret_here"

# --- SECURITY & CORS ---
# The exact URL of your frontend. Express uses this to configure CORS 
# so it only accepts requests from your Next.js app.
FRONTEND_URL="http://localhost:3000"

# --- STRIPE & PAYMENTS ---
# Your secret API key from the Stripe Dashboard (sk_test_...)
STRIPE_SECRET_KEY="sk_test_..."

# The webhook signing secret. You get this after registering your Express 
# webhook endpoint (/api/webhooks/stripe) in the Stripe Dashboard.
STRIPE_WEBHOOK_SECRET="whsec_..."

Security Checklist Before Deployment:
 * Never commit .env files: Ensure both repositories have .env and .env.local listed in their .gitignore files.
 * CORS Configuration: In your Express server.ts or app.ts, ensure the cors middleware strictly uses the FRONTEND_URL variable so malicious domains cannot hit your API.
 * Vercel Setup: When you deploy the Next.js frontend, you will paste the Next.js variables into the Vercel dashboard. When you deploy the Express backend to celltech-backend.vercel.app, you will paste the Backend variables there.
You now have a fully documented, production-ready blueprint for Phase 2.
Are you ready to dive into the codebase and start building, or would you like to review how to properly structure the Express cors middleware to accept the Next.js requests?

