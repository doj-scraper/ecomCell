Integrating authentication in the Next.js App Router using a decoupled Express backend requires the Credentials Provider. Since your database and user validation live on the Express side, NextAuth will act as a session manager (using JWTs) for the frontend.
Here is the functional specification and implementation for Phase 2B.
1. The NextAuth Configuration (lib/auth.ts)
It's best practice to keep the configuration object in a separate file. This allows you to easily import getServerSession(authOptions) into your Server Components later without circular dependencies.
import { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';

export const authOptions: NextAuthOptions = {
  // We use JWTs because the database lives on your Express backend
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30 Days
  },
  providers: [
    CredentialsProvider({
      name: 'iRepair Account',
      credentials: {
        email: { label: 'Email', type: 'email', placeholder: 'tech@shop.com' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        try {
          // 1. Send credentials to your Express backend
          const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/login`, {
            method: 'POST',
            body: JSON.stringify({
               email: credentials.email,
               password: credentials.password 
            }),
            headers: { 'Content-Type': 'application/json' },
          });

          const user = await res.json();

          // 2. If valid, return the user object (must include an 'id')
          if (res.ok && user) {
            return {
              id: user.id,
              email: user.email,
              name: user.name,
              role: user.role, // e.g., 'admin', 'wholesale', 'retail'
              accessToken: user.token // Pass the Express JWT to NextAuth
            };
          }
          return null;
        } catch (error) {
          console.error("Auth backend unreachable:", error);
          return null;
        }
      },
    }),
  ],
  callbacks: {
    // 3. Bake the backend token and role into the NextAuth JWT
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
        token.accessToken = user.accessToken;
      }
      return token;
    },
    // 4. Expose that data to the frontend session (useSession)
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as string;
        session.accessToken = token.accessToken as string;
      }
      return session;
    },
  },
  pages: {
    signIn: '/login', // Redirects here if auth is required
  },
};

2. The Route Handler (app/api/auth/[...nextauth]/route.ts)
With the logic isolated in lib/auth.ts, the actual App Router endpoint is incredibly lean.
import NextAuth from 'next-auth';
import { authOptions } from '@/lib/auth';

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };

3. Route Protection (middleware.ts)
This sits at the root of your Next.js project (same level as app/). It intercepts requests at the edge to ensure unauthenticated users cannot access sensitive routes.
import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/navigation';

export default withAuth(
  function middleware(req) {
    // Optional: Add role-based protection here
    // If a user tries to access /admin but has a 'retail' role, redirect them
    if (
      req.nextUrl.pathname.startsWith('/admin') &&
      req.nextauth.token?.role !== 'admin'
    ) {
      return NextResponse.rewrite(new URL('/unauthorized', req.url));
    }
  },
  {
    callbacks: {
      // Return true if the user has a token, false to redirect to /login
      authorized: ({ token }) => !!token,
    },
  }
);

// Define exactly which routes trigger this middleware
export const config = {
  matcher: [
    '/dashboard/:path*', 
    '/checkout/:path*',
    '/admin/:path*'
  ],
};

4. Integration Discussion
To make this work seamlessly with your existing architecture, consider these points:
 * Type Augmentation: Because we added custom fields (role and accessToken) to the NextAuth session, you will need to create a types/next-auth.d.ts file to extend the default types, otherwise TypeScript will throw errors in your components.
 * The Backend Token: The accessToken captured in the JWT callback is critical. Whenever your Next.js server components need to fetch protected user data (like order history) from the Express backend, you will attach this token to the Authorization: Bearer header.
 * Cart Merge: When a user logs in, NextAuth will trigger a session change. This is the exact moment you should fire a function to take the local Zustand cart (items) and push it to the Express backend to persist it.
The frontend is now heavily structured and protected.
Would you like me to move to Step 5: Redis Cache Infrastructure? I can outline the Express middleware to cache the heavy /api/inventory endpoints, and how to bust that cache when a purchase is made.
