Transitioning from a single-page "infinite scroll" to a structured, multi-page architecture

1. The Architectural Shift
To keep the header and footer persistent while changing the center content,  utilize a Root Layout.



 * app/layout.tsx: Contains your <Header />, <Footer />, and the {children} prop. This ensures they never re-render or "flicker" when navigating.
 
 * app/page.tsx:  loading landing" and the main hero section.
 1. The Persistent Foundation
This layout.tsx file ensures your Header and Footer remain locked in place while the user navigates between the catalog and individual products, eliminating any page-load flickering.
// app/layout.tsx
import Header from '@/components/Header'; // Assuming your header path
import Footer from '@/components/Footer'; // Assuming your footer path
import './globals.css';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      {/* Base light theme matching your pasted code */}
      <body className="bg-[#F5F5F4] text-slate-900 flex flex-col min-h-screen font-sans">
        <Header /> 
        
        {/* flex-grow pushes the footer to the bottom if the page content is short */}
        <main className="flex-grow">
          {children}
        </main>
        
        <Footer />
      </body>
    </html>
  );
 
 
 
 * app/catalog/page.tsx: The searchable grid of products
 
 * app/product/[id]/page.tsx: The focused, individual product view.
 
2. Implementation Strategy

The Persistent Layout
In your layout.tsx, wrap the children in a main container that respects your industrial palette (likely deep grays, slate, or stark whites with heavy borders).

// app/layout.tsx

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-zinc-950 text-zinc-100 flex flex-col min-h-screen">
        <Header /> 
        {/* The 'flex-grow' ensures the footer stays at the bottom even on short pages */}
        <main className="flex-grow">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}

The Focused Product Page
To achieve that "focused" look, use a Master-Detail pattern. When a card is clicked, navigate to a clean page that strips away the noise of the catalog.

 * Visual Tip: Use a "split-screen" layout for products—high-res imagery on the left, technical specs and "Add to Cart" on the right.
 

3. Enhancing the "Focused" Experience

Since you want the transition to feel premium, consider these UI refinements:

 * Framer Motion Transitions: Use a simple opacity fade between pages so the "focused" page doesn't just jump into existence, but feels like it's being "assembled."
 
 * Breadcrumbs: Essential for multi-page navigation. Catalog > Industrial Sensors > Item-402. This fits the professional vibe perfectly.
 
 * Persistent State: Ensure that if a user searches in the catalog, goes to a product, and hits "back," their scroll position and search query are preserved (Next.js handles this well by default).
Next Steps
?





That context is absolute gold. The "Lab Aesthetic" copy and the contrast between a crisp, clean UI (#F5F5F4 background) and those deep, glowing industrial images you uploaded (like the OLED assembly and the camera module) will look incredibly premium for the iRepair brand. It perfectly hits that B2B, supply-chain reliability note.
To execute your goal of breaking away from the infinite scroll and creating that focused catalog-to-product flow, we need to build the structural foundation using Next.js App Router.
Here is how we integrate your exact color palette and uploaded imagery into a persistent layout and a dedicated, highly focused product page.

}

2. The Focused Product Page
When a technician clicks a product card from your catalog, they should land here. This layout uses a split-screen design: a dark, sleek container on the left to make your glowing product images pop, and a clean, data-heavy specification section on the right.
// app/product/[id]/page.tsx
"use client";
import Link from 'next/link';

export default function ProductPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      
      {/* Breadcrumbs for professional navigation */}
      
      <nav className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-8">
      
        <Link href="/" className="hover:text-amber-500 transition-colors">Home</Link>
        <span className="mx-2">/</span>
        <Link href="/catalog" className="hover:text-amber-500 transition-colors">Displays</Link>
        <span className="mx-2">/</span>
        <span className="text-slate-900">iPhone 17 Pro Max</span>
      </nav>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        
        {/* LEFT COLUMN: The "Lab" Image Gallery */}
        
        <div className="bg-[#15121C] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
        
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-transparent"></div>
          
          {/* Using your glowing disassembled screen image */}
          <img 
            src="/images/screen-assembly-glow.png" 
            alt="iPhone 17 Pro Max OLED Flex Cables" 
            className="w-full max-w-md relative z-10 drop-shadow-[0_0_20px_rgba(0,180,255,0.3)]" 
          />
          
          <div className="mt-8 flex gap-4 w-full relative z-10">
            {/* Thumbnail: Camera Module */}
            <button className="border-2 border-amber-500 rounded-lg p-2 bg-slate-900 w-24 h-24 flex items-center justify-center">
              <img src="/images/camera-module.png" alt="Camera Module" className="w-full" />
            </button>
            {/* Thumbnail: Quality Badge */}
            <button className="border border-slate-700 hover:border-slate-500 rounded-lg p-2 bg-slate-900 w-24 h-24 flex items-center justify-center transition-colors">
            
              <img src="/images/certified-badge.png" alt="Grade A Certified" className="w-full opacity-70 hover:opacity-100" />
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: The Data & Purchase Action */}
        <div className="flex flex-col">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-amber-600 mb-4">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> 
            Batch Verified: In Stock
          </div>
          
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight mb-2">
            iPhone 17 Pro Max (A3257) Soft OLED
          </h1>
          <p className="text-slate-500 mb-8 font-mono text-sm">MPN: MFXH4LL/A • Tier-1 Quality</p>

          <div className="bg-white border border-slate-200 rounded-xl p-6 mb-8 shadow-sm">
            <div className="flex justify-between items-end mb-4">
              <span className="text-3xl font-bold text-slate-900">$149.99</span>
              <span className="text-sm text-slate-500 font-medium">1-4 Units</span>
            </div>
            
            <button className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-4 rounded-lg transition-colors shadow-md">
              Add to Bench (Cart)
            </button>
          </div>

          {/* Technical Specs Table */}
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest mb-4 border-b border-slate-200 pb-2">
            Technical Specifications
          </h3>
          <div className="grid grid-cols-2 gap-y-3 font-mono text-sm">
            <div className="text-slate-500">Panel Type</div>
            <div className="text-slate-900 font-semibold text-right">Soft OLED (Flexible)</div>
            
            <div className="text-slate-500">Brightness</div>
            <div className="text-slate-900 font-semibold text-right">400 cd/m² (Luminance)</div>
            
            <div className="text-slate-500">Color Temp</div>
            <div className="text-slate-900 font-semibold text-right">6600 K Calibrated</div>
            
            <div className="text-slate-500">IC Chip</div>
            <div className="text-slate-900 font-semibold text-right">Pre-soldered, Low-profile</div>
          </div>
        </div>
        
      </div>
    </div>
  );
}

Would you like me to map out the app/catalog/page.tsx next so we can build the grid of product cards that link directly into this focused view?





> Role & Objective:
> You are an expert Next.js 14 and Prisma developer. I need you to build the app/catalog/page.tsx for an industrial-grade B2B mobile parts wholesale platform. This must be a Next.js Server Component that fetches data directly from our Neon PostgreSQL database using Prisma.
> Design Language & UI Specs:
>  * Theme: "Clean Industrial Laboratory".
>  * Palette: Background #F5F5F4 (Light Slate), Cards bg-white, Text text-slate-900. Use amber-500 for primary accents/buttons and green-500 for "In-Stock/Tested" status indicators.
>  * Typography: Use sans-serif for general text, but strictly enforce font-mono for all SKU numbers, Part Codes, and Technical Specifications to maintain a "machined" aesthetic.
>  * Layout: A CSS Grid display (3 or 4 columns depending on breakpoint) for the product cards.
> Data Fetching Requirements:
>  * Import the Prisma client (e.g., import prisma from '@/lib/prisma').
>  * Fetch all items from the Inventory table.
>  * You must use include in your Prisma query to join the model data (to get the marketingName) and the category data (to get the name).
>  * Prices are stored in the database as integers (cents). You must map the data to divide wholesalePrice by 100 before rendering the dollar amount on the UI.
> Product Card Component Architecture:
> Each card in the grid must act as a <Link> routing to /product/[skuId]. The card should display:
>  * A placeholder image area at the top (use a dark  background for the image container to contrast the white card).

>  * The marketingName (e.g., iPhone 17 Pro Max) and the category.name (e.g., Display).

>  * The exact skuId rendered in a distinct font-mono text-xs bg-slate-100 p-1 rounded block.

>  * The parsed wholesale price, formatted cleanly (e.g., $149.99).

>  * A visual tag that extracts the "Quality Grade" (OEM, Premium, Aftermarket).

> Please generate the complete app/catalog/page.tsx code. Keep the code strictly typed with TypeScript interfaces for the expected Prisma payload.
> 

Why this Brief Works
 * Server-Side Rendering (SSR): By instructing the agent to build a Server Component, your database calls happen on the server, meaning the catalog will load instantly for the technicians, and the Next.js router handles the heavy lifting without loading spinners.
 
 * Schema Accuracy: It explicitly tells the agent to join the Model and Category tables just like your backend example does for the search endpoint, ensuring the UI has access to the consumer-friendly names, not just raw IDs.
 
 * Financial Integrity: It locks in the cents-to-dollars conversion logic so your UI never accidentally displays an iPhone screen for $14,500 instead of $145.00.
Would you like me to draft a similar prompt specifically for building out the dynamic app/product/[skuId]/page.tsx page, ensuring the agent knows how to query that cross-compatibility mapping table for the individual product view?



That "Secret Sauce" is the most critical piece of your platform. Because wholesale parts are often cross-compatible (like a screen fitting both the iPhone 13 and 14), your product page needs to pull from that CompatibilityMap table to power the Fitment Checker UI.
Here is the exact brief to feed your AI agent to build app/product/[skuId]/page.tsx. It instructs the agent to fetch the cross-compatibility data and build that interactive, green-checkmark verification tool.
Copy & Paste This Prompt to Your AI Agent:

> Role & Objective:
> You are an expert Next.js 14 and Prisma developer. I need you to build a dynamic product detail page (app/product/[skuId]/page.tsx) for a B2B mobile parts wholesale platform.

> Prisma Data Fetching (Server-Side):
>  * Extract the skuId from the URL parameters.
>  * Fetch the item from the Inventory table using prisma.inventory.findUnique.

>  * CRITICAL: You must use include to join both the primary model AND the compatibilities mapping. The query needs to look like this:
>    include: {
>   model: true,
>   category: true,
>   compatibilities: {
>     include: {
>       model: true 
>     }
>   }
> }
> 
>  * Map the wholesalePrice from cents to dollars (divide by 100) before passing it to the UI.

>  * Create a unified array of all compatible modelNumber and marketingName strings (combining the primary model and all models found in the compatibilities array) to pass to the Client Component.

> The Fitment Checker Component (Client-Side):

>  * Create a Client Component ("use client") for the right column of the page called <FitmentChecker />.

>  * Pass the unified array of compatible model names/numbers to this component as a prop.

>  * Create an input field: placeholder="Verify your Model Number (e.g., A3257)".

>  * As the user types, check if their input matches any string in the compatible models array (case-insensitive).

>  * Success State: If a match is found, render a highly visible success block below the input: a green pulse or shield icon, with green font-mono text reading: ✅ 

Confirmed Fit: [Matched Model Name]. Give it a subtle glow 

> Design Language & UI Layout:
>  * Split-Screen Desktop Layout: >   * Left Column: The "Lab Image" gallery. Use a dark container (bg-[#15121C] border-slate-800) to contrast the page's light background.

>    * Right Column: Product title, Price, the <FitmentChecker />, and the "Add to Bench" button (bg-amber-500).

>  * Specs Table: Below the purchase actions, render a 2-column CSS grid for Technical Specifications using font-mono text-sm to look like a technician's spec sheet.

>  * Compatibility Matrix: At the bottom of the right column, build a toggle/accordion that lists every compatible model and its MPN/Model Number clearly, proving the cross-compatibility to the buyer.
> 
How this executes your vision:

 * The Prisma Join: By asking the agent to include the compatibilities relation, the page instantly knows every single phone the part fits.
 
 * The Client Component: The server fetches the data, but the agent will build a separate "use client" component specifically for the search box. This ensures the green checkmark appears instantly as they type, without needing to reload the page.
 
 * The Matrix: It forces the agent to print out the full list of compatible phones, which is exactly what technicians need to see nto trust they won't get a DOA (Dead on Arrival) or incorrect part.
