The Device Explorer (Step 2) is the primary acquisition funnel for your customers. Unlike a generic search bar, this is a guided "drill-down" experience designed to get a user from "I have a broken iPhone" to "Here is the exact screen for my Model A2633" in three clicks.
Functional Spec: Device Explorer (app/catalog/page.tsx)
This page will use a Two-Panel Layout:
1. Sidebar (Filter Tree): A hierarchical navigation of Brand → Series → Model.
2. Main Content (Product Grid): A dynamic grid that filters based on the Sidebar selection.
1. Data Structure & State
To keep the UI snappy, we should fetch the Device Tree (the nested brands and models) as a static JSON object or a cached RSC (React Server Component) call.
