backend middleware 

Shifting to the Express backend. This is where we protect your database from getting hammered every time a customer clicks through the Device Explorer filter tree.
For an e-commerce catalog, read operations heavily outnumber write operations. Implementing a Redis caching layer will drop your /api/inventory response times from ~150ms down to ~5ms.
Here is the functional specification and TypeScript implementation for the Redis caching layer on your backend.
1. The Caching Middleware (middlewares/redisCache.ts)
This middleware sits in front of your heavy GET routes. It intercepts the request, checks Redis for a matching URL key, and either returns the cached data instantly or lets the request pass through to the database (and then caches the result).
import { Request, Response, NextFunction } from 'express';
import { createClient } from 'redis';

// Initialize Redis Client
export const redisClient = createClient({
  url: process.env.REDIS_URL
});

redisClient.on('error', (err) => console.error('Redis Client Error', err));
// Ensure you call redisClient.connect() in your main server.ts

export const cacheInventory = async (req: Request, res: Response, next: NextFunction) => {
  // Only cache GET requests
  if (req.method !== 'GET') {
    return next();
  }

  // Create a unique cache key based on the route and query params
  // e.g., "inventory:/api/inventory/catalog?brand=apple"
  const cacheKey = `inventory:${req.originalUrl}`;

  try {
    const cachedData = await redisClient.get(cacheKey);

    if (cachedData) {
      // CACHE HIT: Return immediately, bypassing the database
      res.setHeader('X-Cache', 'HIT');
      return res.status(200).json(JSON.parse(cachedData));
    }

    // CACHE MISS: Hijack res.json to save the response before sending it
    res.setHeader('X-Cache', 'MISS');
    const originalJson = res.json.bind(res);

    res.json = (body: any) => {
      // Store in Redis with an expiration (e.g., 3600 seconds = 1 hour)
      redisClient.setEx(cacheKey, 3600, JSON.stringify(body));
      return originalJson(body);
    };

    next();
  } catch (error) {
    // Failsafe: If Redis crashes, log the error but allow the request to proceed to the DB
    console.error('Redis Cache Middleware Error:', error);
    next();
  }
};

2. Route Integration (routes/inventory.ts)
Applying this to your Express router is a one-line addition. You place it before the controller logic but after any rate-limiting.
import { Router } from 'express';
import { cacheInventory } from '../middlewares/redisCache';
import { getCatalogTree, getProductBySku } from '../controllers/inventoryController';

const router = Router();

// Apply cache middleware to heavy read routes
router.get('/catalog', cacheInventory, getCatalogTree);
router.get('/:skuId', cacheInventory, getProductBySku);

export default router;

3. Cache Invalidation (The "Bust" Strategy)
Caching is easy; invalidation is the hard part. If a customer buys the last iPhone 13 OLED screen, the frontend needs to know it's out of stock instantly. You cannot wait an hour for the cache to expire.
You need an invalidation utility that gets called whenever inventory is modified.
import { redisClient } from '../middlewares/redisCache';

/**
 * Purges all cached keys related to inventory.
 * Call this after a successful purchase or admin inventory update.
 */
export const bustInventoryCache = async () => {
  try {
    // Find all keys starting with 'inventory:'
    const keys = await redisClient.keys('inventory:*');
    
    if (keys.length > 0) {
      await redisClient.del(keys);
      console.log(`[Cache] Purged ${keys.length} inventory keys.`);
    }
  } catch (error) {
    console.error('Failed to bust cache:', error);
  }
};

4. Architectural Discussion Points
 * Granular vs. Global Invalidation: The bustInventoryCache function above uses a "nuclear" approach—clearing all inventory caches. For a massive catalog, you might want to only bust the specific skuId and the specific brand tree it belongs to.
 * Failsafe Design: Notice the try/catch block in the middleware. If your Redis instance goes down, the application will simply fall back to querying the database rather than throwing 500 errors to your customers.
 * Frontend Sync: Since you are using Next.js 15, you also have Next's internal fetch cache. You need to ensure your lib/api.ts on the frontend is either set to cache: 'no-store' for these specific routes, or you use Next's revalidateTag to bust the frontend cache at the same time you bust the Redis cache.
Final Phase: Checkout & Stripe
We have now mapped out the Product Details, the Catalog UI, the Cart State, User Auth, and Backend Caching. The final piece of the puzzle is taking the money.
Would you like me to map out Phase 2D: The Stripe Checkout Flow? We can define how the frontend creates the session and how the Express backend listens to the Stripe Webhook to trigger that cache-busting function we just wrote.

The Stripe integration is the final bridge. Since you are using a decoupled architecture (Next.js frontend + Express backend), security and data integrity are paramount. The golden rule of e-commerce is: Never trust the frontend cart for pricing.
Here is the functional specification and architecture for the Stripe Checkout and Webhook flow.
1. The Checkout Flow Architecture
 * Frontend (Next.js): User clicks "Proceed to Checkout" in the Cart Drawer. The frontend sends an array of { skuId, quantity } to the Express backend.
 * Backend (Express): Looks up the actual database price for each SKU, builds a Stripe Session, and returns a checkoutUrl.
 * Frontend (Next.js): Redirects the user to the Stripe-hosted payment page.
 * Backend (Express): Listens for a server-to-server Webhook from Stripe (checkout.session.completed). When received, it deducts inventory, creates the order in your database, and busts the Redis cache.
2. Backend: Creating the Session (controllers/checkoutController.ts)
This endpoint receives the cart from the frontend, validates the items against your database, and generates the Stripe URL.
import { Request, Response } from 'express';
import Stripe from 'stripe';
import { db } from '../db'; // Your database instance

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

export const createCheckoutSession = async (req: Request, res: Response) => {
  try {
    const { items } = req.body; // Array of { skuId, quantity }
    const userId = req.user?.id; // Assuming auth middleware ran first

    // 1. Map frontend SKUs to actual Database prices to prevent manipulation
    const lineItems = await Promise.all(
      items.map(async (item: any) => {
        const product = await db.products.findBySku(item.skuId);
        
        if (!product) throw new Error(`Product ${item.skuId} not found`);
        if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${item.skuId}`);

        return {
          price_data: {
            currency: 'usd',
            product_data: {
              name: product.name,
              metadata: { skuId: item.skuId }, // Attach SKU for the webhook later
            },
            unit_amount: Math.round(product.basePrice * 100), // Stripe expects cents
          },
          quantity: item.quantity,
        };
      })
    );

    // 2. Create the Stripe Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: lineItems,
      customer_email: req.user?.email, // Pre-fill if logged in
      metadata: {
        userId: userId || 'guest',
      },
      // Redirect URLs back to your Next.js app
      success_url: `${process.env.FRONTEND_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/cart`,
    });

    res.status(200).json({ url: session.url });
  } catch (error) {
    console.error('Stripe Session Error:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
};

3. Backend: The Webhook Listener (routes/webhook.ts)
Critical Setup Detail: Stripe webhooks require the raw unparsed request body to verify the cryptographic signature. If your Express app uses a global express.json() middleware, the webhook will fail signature validation. You must bypass the JSON parser for this specific route.
import { Router } from 'express';
import express from 'express';
import Stripe from 'stripe';
import { bustInventoryCache } from '../middlewares/redisCache';
import { db } from '../db';

const router = Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// NOTE: Use express.raw() exclusively for this route
router.post(
  '/stripe', 
  express.raw({ type: 'application/json' }), 
  async (req, res) => {
    const sig = req.headers['stripe-signature'] as string;
    let event: Stripe.Event;

    try {
      // 1. Verify the payload actually came from Stripe
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET!
      );
    } catch (err: any) {
      console.error(`Webhook signature verification failed: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    // 2. Handle the successful payment event
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session;
      
      // Fetch the line items to know exactly what was purchased
      const lineItems = await stripe.checkout.sessions.listLineItems(session.id);

      try {
        // 3. Database Transaction: Create Order & Deduct Stock
        await db.transaction(async (trx) => {
          // Create order record...
          // Deduct inventory for each skuId found in lineItems.data[].price.product.metadata...
        });

        // 4. Invalidate the Redis Cache so the frontend updates immediately
        await bustInventoryCache();
        
      } catch (dbError) {
        console.error('Failed to process order in DB:', dbError);
        // Important: Still return 200 to Stripe so it doesn't retry, 
        // but log this critically for manual intervention.
      }
    }

    // Acknowledge receipt to Stripe
    res.status(200).json({ received: true });
  }
);

export default router;

4. Frontend Integration (components/CartDrawer.tsx update)
Back on the Next.js side, the handleCheckout function in your Cart Drawer simply posts to your new Express endpoint and redirects the browser.
const handleCheckout = async () => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/checkout/create-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // 'Authorization': `Bearer ${session?.accessToken}` // If using NextAuth
      },
      body: JSON.stringify({ items }), // The Zustand store items
    });

    const data = await response.json();
    
    if (data.url) {
      window.location.href = data.url; // Redirect to Stripe
    }
  } catch (error) {
    console.error("Checkout failed", error);
    // Show a toast notification to the user here
  }
};

The Full Picture
We have now mapped out all of Phase 2:
 * 2A: PDP & Fitment Checker, Catalog Device Explorer, Cart Drawer UI.
 * 2B: NextAuth JWT bridging to your Express user database.
 * 2C: Redis caching middleware for high-speed inventory reads.
 * 2D: Stripe session creation and webhook order fulfillment.
Would you like me to compile all of these architectural decisions and code snippets into a unified ARCHITECTURE.md file that you can drop into your repository for your team to reference as you build?
