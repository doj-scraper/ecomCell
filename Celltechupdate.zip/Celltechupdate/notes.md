

Here is the comprehensive Phase 2 architecture specification. This is structured as a master blueprint that you can drop directly into an ARCHITECTURE.md file in the root of the iRepair repository. If the code ever gets lost, this document contains all the exact logic, data shapes, and systemic flows needed to rebuild it.
iRepair E-Commerce Platform: Phase 2 Architecture Specification
1. System Overview
The iRepair platform utilizes a decoupled architecture prioritizing high-performance reads for hardware cataloging and secure, transactional writes for the checkout process.
 * Frontend: Next.js 15 (App Router), React, TypeScript, Tailwind CSS, shadcn/ui.
 * Design Language: Industrial, high-contrast, non-glassmorphic. Dark mode optimized with strict ct-* token adherence.
 * Backend: Node.js / Express (REST API).
 * Database / Cache: PostgreSQL (assumed core DB) + Redis (in-memory caching).
 * Infrastructure Auth & Payments: NextAuth.js (JWT bridging) + Stripe (Checkout & Webhooks).
2. Global State Management (Zustand)
The frontend relies on three primary Zustand stores, all utilizing persist (localStorage) where applicable to survive page reloads.
 * useCartStore: Manages the items array ({ skuId, quantity, price, name }), totalAmount, and actions (updateQuantity, removeItem). Must handle guest-to-user cart merging upon login.
 * useDeviceStore: Manages the "My Garage" experience. Stores a single savedDevice object. This automatically drives the Fitment Checker UI when navigating the catalog.
 * useAppStore: Handles ephemeral UI states, specifically isCartOpen to trigger the global slide-out drawer.
3. Core Feature Specifications (Phase 2A)
3.1 The Fitment Checker (PDP Level)
A client-side matching engine living on the Product Detail Page (PDP) that prevents incorrect part purchases.
 * Data Shape: The backend flattens device compatibilities into a searchable array per SKU.
 * Matching Algorithm:
   * Exact Match: Normalizes input (lowercasing, stripping hyphens/spaces) and checks strictly against device modelNumbers (e.g., A2633).
   * Partial Match: Falls back to displayName or series string matching if no exact hardware number is found.
 * Persistence: Upon finding an exact match, prompts the user to "Save Device", updating useDeviceStore.
3.2 Device Explorer Catalog
A two-panel drill-down interface designed to funnel users from generic brands to highly specific hardware.
 * Routing: Driven entirely by URL search parameters (/catalog?brand=apple&series=iphone13). This ensures shareability and SEO indexing.
 * Data Fetching: The sidebar tree (Brand → Series → Model) is fetched server-side. The product grid updates asynchronously via Suspense based on the active URL parameters.
 * UI/UX: Replaces the data-dense app/inventory table (which is reserved for staff/admin) with a visual, high-margin product card grid.
3.3 The Cart Drawer
A slide-out sheet (right-aligned) acting as the bridge between browsing and purchasing.
 * Mechanics: Subscribes to useCartStore. Updates quantities optimistically on the client.
 * Constraints: Prevents users from incrementing quantity beyond the backend's known stock limits (requires stock validation hook).
4. Authentication Architecture (Phase 2B)
NextAuth.js acts as a frontend session manager, bridging to the Express backend via a Custom Credentials Provider.
 * Strategy: JWT (JSON Web Tokens). Database sessions are not used on the Next.js side.
 * Flow:
   * User submits email/password. NextAuth authorize callback POSTs to Express /api/auth/login.
   * Express validates against the DB and returns a backend JWT and user role.
   * NextAuth bakes the Express JWT and role into its own Next.js session token.
 * Middleware: Next.js edge middleware protects /checkout and /dashboard routes, redirecting unauthenticated users to /login.
 * API Requests: Server Components pull the backend token from the NextAuth session and attach it as a Bearer token for all authenticated requests to Express.
5. Caching Infrastructure (Phase 2C)
To protect the database from redundant queries during catalog browsing, Redis sits between the Express controllers and the database.
 * Middleware (cacheInventory): Intercepts GET /api/inventory/*.
   * Cache Hit: Returns Redis payload immediately (X-Cache: HIT).
   * Cache Miss: Proceeds to database, hijacks the response stream, saves to Redis (1-hour TTL), and returns data.
 * Invalidation Strategy: The cache is aggressively busted (purged) whenever a successful purchase webhook is received or an admin manually updates inventory quantities.
6. Payment & Fulfillment Flow (Phase 2D)
A strictly server-authoritative checkout process using Stripe.
 * Session Creation: The frontend cart drawer POSTs an array of { skuId, quantity } to the Express backend.
 * Price Validation: Express ignores frontend pricing. It queries the database for the true basePrice of each SKU to build the Stripe line items.
 * Handoff: Express returns a Stripe Session URL; Next.js redirects the user.
 * The Webhook (The Source of Truth):
   * Express listens on a raw, unparsed endpoint for checkout.session.completed.
   * Cryptographically verifies the Stripe signature.
   * Executes a database transaction: Creates the order record and decrements SKU inventory.
   * Fires the Redis bustInventoryCache() utility to instantly update frontend stock displays.
lol
This is the final piece of the Fitment Checker pipeline. By writing this specific controller, we are bridging the relational data in your PostgreSQL database directly to the flat, fast JSON structure that your Next.js 15 frontend expects.
When architecting a wholesale repair platform, minimizing the payload size between the backend and frontend is crucial for speed. We want the database to do the heavy lifting of joining the tables, and the Express server to handle flattening the data before sending it over the wire.
1. The Express Controller (controllers/inventoryController.ts)
This controller queries the CompatibilityMap, joins the necessary Model and Brand data, and maps it to match the exact Device TypeScript interface we built for the frontend.
import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

// Initialize Prisma (Ensure you are using a connection pooler 
// URL if deploying this to Vercel serverless functions)
const prisma = new PrismaClient();

export const getProductCompatibilities = async (req: Request, res: Response) => {
  try {
    const { skuId } = req.params;

    // 1. Query the Join Table and Include Relations
    const compatibilities = await prisma.compatibilityMap.findMany({
      where: { 
        skuId: skuId 
      },
      include: {
        model: {
          include: {
            brand: true, // Pulls the Brand name (e.g., "Apple")
          }
        }
      }
    });

    // 2. Handle Empty States
    if (!compatibilities.length) {
      return res.status(200).json([]); // Return empty array, not a 404
    }

    // 3. Transform the Data for the Frontend
    // We flatten the nested Prisma response into the clean `Device[]` 
    // array that your Next.js FitmentChecker component expects.
    const fitmentData = compatibilities.map((record) => {
      const device = record.model;
      return {
        id: device.id.toString(),
        brand: device.brand.name,
        // Fallback to empty string if marketingName is null
        series: device.marketingName || '', 
        modelName: device.marketingName || 'Unknown Model',
        // modelNumbers is already a String[] in your updated Prisma schema
        modelNumbers: device.modelNumbers, 
        releaseYear: device.releaseYear,
      };
    });

    // 4. Send the optimized payload
    res.status(200).json(fitmentData);

  } catch (error) {
    console.error(`[Inventory Controller] Error fetching compatibilities for ${req.params.skuId}:`, error);
    res.status(500).json({ error: 'Failed to fetch fitment data' });
  }
};

2. The Express Route (routes/inventory.ts)
Now, wire that controller to your Express router. This is also where you apply the Redis caching middleware we discussed in Phase 2C to ensure this endpoint returns in milliseconds.
import { Router } from 'express';
import { getProductCompatibilities } from '../controllers/inventoryController';
import { cacheInventory } from '../middlewares/redisCache';

const router = Router();

// ... other inventory routes (e.g., /catalog, /:skuId)

// Apply the Redis cache middleware so repeated fitment checks don't hit Postgres
router.get(
  '/:skuId/compatibilities', 
  cacheInventory, 
  getProductCompatibilities
);

export default router;

3. The Full Pipeline Review
With this code in place, the complete Phase 2A Fitment loop is closed:
 * User visits /product/SCRN-IPH13-OLED on the frontend.
 * Next.js Server Component calls GET /api/inventory/SCRN-IPH13-OLED/compatibilities.
 * Express hits the cacheInventory middleware.
 * If a Cache Miss occurs, Prisma queries the CompatibilityMap table in PostgreSQL.
 * Express formats the complex SQL join into a flat JSON array and caches it in Redis.
 * Next.js passes that clean array directly into the <FitmentChecker /> Client Component.
 * User types "A2633" and gets an instant, zero-latency "Exact Match" UI update.
This architecture creates a massive moat in terms of user experience compared to standard Shopify or WooCommerce templates.



The Device Explorer Sidebar is the backbone of your catalog's navigation. Since this hierarchical data (Brand → Models) is needed on almost every page load in the /catalog section, we need to ensure the Express controller formats it exactly how the frontend expects it, minimizing client-side computation.
Here is the implementation for the controller that queries your updated Prisma schema and transforms it into the recursive DeviceNode structure.
1. The Express Controller (controllers/catalogController.ts)
This controller pulls all brands and their associated models, ordering them logically (alphabetically for brands, newest first for models).
import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const getCatalogTree = async (req: Request, res: Response) => {
  try {
    // 1. Fetch Brands and include their related Models
    const brands = await prisma.brand.findMany({
      orderBy: { name: 'asc' }, // e.g., Apple, Google, Samsung
      include: {
        models: {
          orderBy: { releaseYear: 'desc' }, // Show newest devices first
          select: {
            id: true,
            marketingName: true,
            modelNumbers: true,
          }
        }
      }
    });

    // 2. Transform the Prisma output into the frontend `DeviceNode` structure
    const deviceTree = brands.map((brand) => {
      return {
        id: `brand-${brand.id}`,
        label: brand.name,
        // Map the nested models into the 'children' array
        children: brand.models.map((model) => ({
          id: `model-${model.id}`,
          // Fallback to the first model number if marketingName is missing
          label: model.marketingName || model.modelNumbers[0] || 'Unknown Model',
        }))
      };
    });

    // 3. Return the optimized tree
    res.status(200).json(deviceTree);

  } catch (error) {
    console.error('[Catalog Controller] Error fetching device tree:', error);
    res.status(500).json({ error: 'Failed to fetch catalog navigation tree' });
  }
};

2. Route Integration (routes/catalog.ts)
Just like the Fitment Checker, this is a prime candidate for your Redis cache middleware. The hardware tree rarely changes (only when a new device is released), so caching it prevents unnecessary database hits.
import { Router } from 'express';
import { getCatalogTree } from '../controllers/catalogController';
import { cacheInventory } from '../middlewares/redisCache';

const router = Router();

// Apply cache middleware to the heavy read route
router.get('/tree', cacheInventory, getCatalogTree);

export default router;

3. A Quick Note on the "Series" Grouping
In the frontend spec, we discussed a three-level drill-down: Brand → Series → Model (e.g., Apple → iPhone 13 → iPhone 13 Pro).
Currently, your Prisma Model table handles two levels natively: Brand → Model.
If you want to achieve that middle "Series" grouping later without altering the database schema again, you can group them dynamically in the controller using string parsing (e.g., checking if marketingName includes "iPhone 13" and grouping all variants under it before sending it to the frontend). For now, the two-level tree perfectly satisfies the DeviceNode interface and gets the catalog functioning.
The Architecture is Complete
You now have the exact frontend Next.js code and the backend Express/Prisma pipelines for the two most complex Phase 2 features:
 * The Fitment Checker
 * The Device Explorer
With these patterns established, you have a rock-solid blueprint for handling the Auth and Stripe phases when you get to them.
Would you like me to help draft the Next.js Server Action that handles the Stripe Checkout redirection, or are you ready to jump into your code editor and start bringing this to life?



