cart drawer/checkout 

Using a Server Action in Next.js 15 is the perfect way to handle this. By moving the checkout request from the client to the server, you gain two massive benefits:
 * Security: You don't expose your Express backend URL (NEXT_PUBLIC_API_URL) to the browser for checkout processes.
 * Auth Integration: You can securely read the user's NextAuth session server-side and attach the required JWT Bearer token before hitting your Express API, all without exposing the token to the client.
Here is the exact Server Action and how you wire it into your Cart Drawer.
1. The Server Action (app/actions/checkout.ts)
In Next.js, redirect() throws an error internally to halt execution and perform the routing. Because of this, you must be careful not to trap it inside a try/catch block.
'use server';

import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

interface CheckoutItem {
  skuId: string;
  quantity: number;
}

export async function initiateCheckout(items: CheckoutItem[]) {
  // 1. Check for an active session to grab the Express backend token
  const session = await getServerSession(authOptions);
  let checkoutUrl: string | null = null;

  try {
    // 2. Call your Express backend
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/checkout/create-session`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Attach the Express JWT if the user is logged in
        ...(session?.accessToken && { Authorization: `Bearer ${session.accessToken}` }),
      },
      body: JSON.stringify({ items }),
      // Do not cache checkout requests
      cache: 'no-store', 
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to initialize checkout');
    }

    const data = await response.json();
    checkoutUrl = data.url;

  } catch (error) {
    console.error('[Server Action] Checkout Error:', error);
    // Return an error state to the client so it can show a toast notification
    return { success: false, error: 'Failed to connect to checkout service.' };
  }

  // 3. Execute the redirect outside the try/catch block
  if (checkoutUrl) {
    redirect(checkoutUrl);
  }
}

2. Client Integration (components/CartDrawer.tsx)
Now, we update the CartDrawer we built in Phase 2A. Instead of making a fetch call directly from the browser, we invoke the Server Action using Next.js 15's useTransition hook. This allows you to show a loading state on the checkout button while the server does the heavy lifting.
'use client';

import { useState, useTransition } from 'react';
import { initiateCheckout } from '@/app/actions/checkout';
import { useCartStore } from '@/store/useCartStore';

// ... (inside your CartDrawer component)

const { items, totalAmount } = useCartStore();
const [isPending, startTransition] = useTransition();
const [checkoutError, setCheckoutError] = useState<string | null>(null);

const handleCheckout = () => {
  setCheckoutError(null);
  
  // Format items for the server action
  const checkoutPayload = items.map(item => ({
    skuId: item.skuId,
    quantity: item.quantity
  }));

  // startTransition keeps the UI responsive while the Server Action runs
  startTransition(async () => {
    const result = await initiateCheckout(checkoutPayload);
    
    // If we get a result back, it means the redirect failed or an error was caught
    if (result && !result.success) {
      setCheckoutError(result.error);
    }
  });
};

return (
  // ... your existing drawer UI ...
  
  <SheetFooter className="border-t border-industrial-800 pt-6 flex-col gap-4">
    <div className="flex justify-between items-end">
      <span className="text-xs font-mono uppercase opacity-50">Subtotal</span>
      <span className="text-xl font-bold font-mono">${totalAmount.toFixed(2)}</span>
    </div>
    
    {/* Error Message Display */}
    {checkoutError && (
      <div className="text-red-500 text-xs font-mono text-center mb-2">
        {checkoutError}
      </div>
    )}

    <button 
      onClick={handleCheckout}
      disabled={isPending || items.length === 0}
      className="w-full py-4 bg-primary text-primary-foreground font-bold uppercase tracking-widest hover:brightness-110 transition-all disabled:opacity-50"
    >
      {isPending ? 'Connecting to Secure Checkout...' : 'Proceed to Checkout'}
    </button>
  </SheetFooter>
);

The Power of this Flow
By bridging Zustand, a Next.js Server Action, and your decoupled Express API, you've created a highly secure flow. The client only ever sees the generic skuId and quantity. Pricing, stock validation, and token authentication are handled entirely server-to-server.
You now have a complete, end-to-end blueprint for the iRepair platform.
Would you like me to map out how to structure the success_url page (app/checkout/success/page.tsx) to catch the user when Stripe sends them back and clear their Zustand cart?





The success_url page is the final touchpoint of the checkout flow. Because your architecture splits the truth between the backend (Stripe Webhook + Express database) and the frontend (Zustand localStorage), this page has two distinct jobs:
 * Server-Side: Securely verify the session_id and display the final order confirmation.
 * Client-Side: Wipe the local Zustand cart so the user doesn't accidentally re-purchase the same screens.
To handle this cleanly in Next.js 15, we use a hybrid approach: a Server Component for the UI and data fetching, and a tiny, invisible Client Component strictly for purging the cart.
1. The Client Cart Purger (components/checkout/CartPurger.tsx)
Because Zustand's persist middleware relies on the browser's localStorage, we cannot clear it from a Server Component. We need a dedicated client hook that fires exactly once when the success page mounts.
'use client';

import { useEffect, useRef } from 'react';
import { useCartStore } from '@/store/useCartStore';

export default function CartPurger() {
  const clearCart = useCartStore((state) => state.clearCart);
  const hasCleared = useRef(false);

  useEffect(() => {
    // Prevent strict-mode double firing
    if (!hasCleared.current) {
      clearCart();
      hasCleared.current = true;
    }
  }, [clearCart]);

  return null; // This component renders nothing visually
}

(Note: Ensure your useCartStore has a clearCart: () => set({ items: [], totalAmount: 0 }) action defined).
2. The Success Page (app/checkout/success/page.tsx)
This Server Component grabs the Stripe session ID from the URL parameters, confirms the order is real, and renders a high-contrast, industrial receipt.
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { CheckCircle, ArrowRight, FileText } from 'lucide-react';
import CartPurger from '@/components/checkout/CartPurger';

interface SuccessPageProps {
  searchParams: Promise<{ session_id?: string }>;
}

export default async function CheckoutSuccessPage({ searchParams }: SuccessPageProps) {
  const { session_id } = await searchParams;

  // 1. Guard Clause: No session ID? Boot them back to the catalog.
  if (!session_id) {
    redirect('/catalog');
  }

  // 2. (Optional but recommended) Fetch the actual order from your Express backend
  // const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/orders/verify?session_id=${session_id}`);
  // const order = await res.json();

  return (
    <main className="min-h-[80vh] flex items-center justify-center p-4">
      {/* 3. Invisible Client Component to wipe Zustand */}
      <CartPurger />

      {/* 4. Industrial UI Receipt Wrapper */}
      <div className="max-w-md w-full border-2 border-industrial-700 bg-industrial-900 p-8 shadow-2xl relative overflow-hidden">
        
        {/* Decorative Hardware Accent */}
        <div className="absolute top-0 left-0 w-full h-1 bg-primary" />
        
        <header className="flex flex-col items-center text-center mb-8">
          <div className="w-16 h-16 bg-primary/10 flex items-center justify-center rounded-none border border-primary/30 mb-6">
            <CheckCircle className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold uppercase tracking-tight">
            Order Confirmed
          </h1>
          <p className="text-sm font-mono text-muted-foreground mt-2">
            SESSION_REF: {session_id.slice(-8).toUpperCase()}
          </p>
        </header>

        <div className="border-t border-b border-industrial-800 py-6 my-6 space-y-4 font-mono text-sm">
          <div className="flex justify-between">
            <span className="opacity-60">Status</span>
            <span className="text-green-400">PAID & QUEUED</span>
          </div>
          <div className="flex justify-between">
            <span className="opacity-60">Fulfillment</span>
            <span>STANDARD</span>
          </div>
          {/* If you fetched the order, map the real totals here */}
        </div>

        <div className="flex flex-col gap-3 mt-8">
          <Link 
            href="/dashboard/orders"
            className="w-full flex items-center justify-center gap-2 py-4 border border-industrial-700 hover:bg-industrial-800 transition-colors font-bold uppercase text-xs tracking-widest"
          >
            <FileText className="w-4 h-4" />
            View Order History
          </Link>
          
          <Link 
            href="/catalog"
            className="w-full flex items-center justify-center gap-2 py-4 bg-primary text-primary-foreground hover:brightness-110 transition-colors font-bold uppercase text-xs tracking-widest"
          >
            Return to Catalog
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </main>
  );
}

The Full Checkout Cycle is Complete
With this page, the user has gone from browsing a highly specific hardware tree, finding a part with a guaranteed fitment check, sliding out the cart drawer, securely transacting via Stripe, and landing on a clean, system-cleared success page.





We have a link pointing to /dashboard/orders in the success UI. Would you like me to map out the structure for that protected NextAuth User Dashboard next?
